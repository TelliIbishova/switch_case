// switch case Tapşırığı — Fəsilə görə Aylar
// İstifadəçidən fəsil daxil et:
// "yay" → İyun, İyul, Avqust
// "qış" → Dekabr, Yanvar, Fevral
// "yaz" → Mart, Aprel, May
// "payız" → Sentyabr, Oktyabr, Noyabr
// Əgər səhv daxil edilərsə:
// JavaScript
// "Belə fəsil yoxdur"

let fesil = prompt("fesilleri daxil et");
switch(fesil){
    case "yay":
        alert("İyun, İyul, Avqust");
        break;
        case "qiş":
        alert("Dekabr, Yanvar, Fevral");
        break;
        case "yaz":
        alert("Mart, Aprel, May");
        break;
        case "payiz":
        alert("Sentyabr, Oktyabr, Noyabr");
        break;
        default:
            alert("Belə fəsil yoxdur");

}